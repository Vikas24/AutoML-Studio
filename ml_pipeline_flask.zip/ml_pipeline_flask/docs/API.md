# ML Pipeline REST API Documentation

## Base URL
```
http://localhost:5000/api
```

## Authentication
Not required (add authentication in production)

---

## Endpoints Reference

### 1. Health Check

**GET** `/health`

Check if API is running.

**Response:**
```json
{
    "status": "healthy",
    "message": "ML Pipeline API is running"
}
```

---

### 2. Get Version

**GET** `/version`

Get API version information.

**Response:**
```json
{
    "version": "1.0.0",
    "name": "ML Pipeline API",
    "description": "Automated ML pipeline with decision logging"
}
```

---

### 3. Upload File

**POST** `/upload`

Upload a CSV file for processing.

**Headers:**
```
Content-Type: multipart/form-data
```

**Body:**
```
file: <CSV file>
```

**Response (200):**
```json
{
    "session_id": "a1b2c3d4",
    "filename": "customer_data.csv",
    "shape": [1000, 15],
    "columns": ["age", "income", "churn", "..."],
    "dtypes": {
        "age": "int64",
        "income": "float64",
        "churn": "object"
    },
    "preview": [
        {"age": 25, "income": 50000, "churn": "No"},
        {"age": 35, "income": 75000, "churn": "Yes"}
    ],
    "missing_values": {
        "age": 0,
        "income": 2,
        "churn": 0
    },
    "sample_values": {
        "age": [25, 35, 45, 55, 65],
        "churn": ["Yes", "No"]
    }
}
```

**Response (400):**
```json
{
    "error": "Only CSV files allowed"
}
```

---

### 4. Run Pipeline

**POST** `/pipeline/run`

Execute the complete ML pipeline.

**Headers:**
```
Content-Type: application/json
```

**Body:**
```json
{
    "session_id": "a1b2c3d4",
    "target_column": "churn"
}
```

Or for unsupervised learning:
```json
{
    "session_id": "a1b2c3d4",
    "target_column": null
}
```

**Response (200):**
```json
{
    "session_id": "a1b2c3d4",
    "status": "success",
    "problem_type": "classification",
    "model": "RandomForestClassifier",
    "metrics": {
        "accuracy": 0.88,
        "precision": 0.85,
        "recall": 0.80,
        "f1": 0.82,
        "roc_auc": 0.91
    },
    "decisions": {
        "problem_type": {
            "type": "classification",
            "target_column": "churn",
            "subtype": "classification",
            "explanation": "Binary classification detected..."
        },
        "preprocessing": {
            "imputation": "mean",
            "scaling": "standard",
            "encoding": {"city": "label"},
            "explanation": "StandardScaler applied..."
        },
        "model_selection": {
            "selected_model": "RandomForestClassifier",
            "cv_scores": {
                "LogisticRegression": 0.82,
                "RandomForestClassifier": 0.88
            },
            "best_cv_score": 0.88,
            "reason": "Best CV F1-score among candidates"
        },
        "evaluation": {
            "metrics": {...},
            "explanation": "Model accuracy: 0.88..."
        },
        "error_analysis": {
            "false_positives": 45,
            "false_negatives": 12,
            "insights": ["More FP than FN..."],
            "explanation": "Error Analysis: 45 FP, 12 FN..."
        }
    }
}
```

---

### 5. Get Pipeline Status

**GET** `/pipeline/status/<session_id>`

Get current status of pipeline execution.

**Response:**
```json
{
    "session_id": "a1b2c3d4",
    "status": "completed",
    "problem_type": "classification",
    "model": "RandomForestClassifier"
}
```

---

### 6. Get Decisions

**GET** `/decisions/<session_id>`

Get full decision log in JSON format.

**Response:**
```json
{
    "timestamp": "2024-02-03T10:30:00.123456",
    "decisions": {
        "data_validation": {...},
        "problem_type": {...},
        "preprocessing": {...},
        "feature_engineering": {...},
        "train_test_split": {...},
        "class_imbalance": {...},
        "model_selection": {...},
        "hyperparameter_tuning": {...},
        "evaluation": {...},
        "error_analysis": {...}
    }
}
```

---

### 7. Get Decisions as Text

**GET** `/decisions/<session_id>/text`

Get decision log as human-readable text report.

**Response:**
```json
{
    "session_id": "a1b2c3d4",
    "report": "============================================================\nML PIPELINE DECISION LOG\n============================================================\n\n📌 DATA_VALIDATION\n   Data validation: 0.5% missing, 0 duplicates...\n\n[Full report text]"
}
```

---

### 8. Get Stage Decision

**GET** `/decisions/<session_id>/stage/<stage_name>`

Get decision for a specific pipeline stage.

**Stage Names:**
- `data_validation`
- `problem_type`
- `preprocessing`
- `feature_engineering`
- `train_test_split`
- `class_imbalance`
- `model_selection`
- `hyperparameter_tuning`
- `evaluation`
- `error_analysis`
- `dimensionality_reduction` (unsupervised)
- `clustering` (unsupervised)

**Example:**
```
GET /decisions/a1b2c3d4/stage/model_selection
```

**Response:**
```json
{
    "stage": "model_selection",
    "decision": {
        "selected_model": "RandomForestClassifier",
        "cv_scores": {
            "LogisticRegression": 0.82,
            "RandomForestClassifier": 0.88
        },
        "best_cv_score": 0.88,
        "reason": "Best CV F1-score among candidates",
        "explanation": "RandomForest selected with best CV score: 0.88"
    }
}
```

---

### 9. Export Decisions as JSON

**GET** `/export/<session_id>/json`

Export full decisions in downloadable JSON format.

**Response:**
```json
{
    "filename": "pipeline_decisions_a1b2c3d4.json",
    "data": {
        "timestamp": "2024-02-03T10:30:00",
        "decisions": {...}
    }
}
```

---

### 10. Export Report as Text

**GET** `/export/<session_id>/text`

Export report in downloadable text format.

**Response:**
```json
{
    "filename": "pipeline_report_a1b2c3d4.txt",
    "content": "[Full report text]"
}
```

---

### 11. Get Data Statistics

**GET** `/analysis/<session_id>/stats`

Get data statistics for uploaded file.

**Response:**
```json
{
    "shape": [1000, 15],
    "columns": ["age", "income", "churn"],
    "dtypes": {
        "age": "int64",
        "income": "float64"
    },
    "missing": {
        "age": 0,
        "income": 2
    },
    "duplicates": 3,
    "numeric_summary": {
        "age": {
            "count": 1000,
            "mean": 45.5,
            "std": 15.3,
            "min": 18,
            "25%": 35,
            "50%": 46,
            "75%": 56,
            "max": 85
        }
    }
}
```

---

### 12. Get Column Information

**GET** `/analysis/<session_id>/columns`

Get detailed information about each column.

**Response:**
```json
{
    "columns": [
        {
            "name": "age",
            "dtype": "int64",
            "missing": 0,
            "unique": 68,
            "sample": [25, 35, 45]
        },
        {
            "name": "income",
            "dtype": "float64",
            "missing": 2,
            "unique": 999,
            "sample": [50000.0, 75000.5, 100000.0]
        },
        {
            "name": "churn",
            "dtype": "object",
            "missing": 0,
            "unique": 2,
            "sample": ["Yes", "No"]
        }
    ]
}
```

---

### 13. List Sessions

**GET** `/sessions`

List all active sessions.

**Response:**
```json
{
    "sessions": [
        {
            "session_id": "a1b2c3d4",
            "has_file": true,
            "has_results": true
        },
        {
            "session_id": "e5f6g7h8",
            "has_file": true,
            "has_results": false
        }
    ]
}
```

---

### 14. Delete Session

**DELETE** `/sessions/<session_id>`

Delete session and clean up uploaded file.

**Response:**
```json
{
    "message": "Session deleted"
}
```

---

## Error Responses

### 400 Bad Request
```json
{
    "error": "Invalid request parameters"
}
```

### 404 Not Found
```json
{
    "error": "Session not found"
}
```

### 500 Internal Server Error
```json
{
    "error": "Internal server error"
}
```

---

## Usage Examples

### cURL

```bash
# Upload file
curl -F "file=@data.csv" http://localhost:5000/api/upload

# Run pipeline
curl -X POST http://localhost:5000/api/pipeline/run \
  -H "Content-Type: application/json" \
  -d '{"session_id": "a1b2c3d4", "target_column": "churn"}'

# Get decisions
curl http://localhost:5000/api/decisions/a1b2c3d4
```

### Python

```python
import requests

# Upload file
with open('data.csv', 'rb') as f:
    files = {'file': f}
    r = requests.post('http://localhost:5000/api/upload', files=files)
    session = r.json()
    session_id = session['session_id']

# Run pipeline
data = {
    'session_id': session_id,
    'target_column': 'churn'
}
r = requests.post('http://localhost:5000/api/pipeline/run', json=data)
results = r.json()

# Get decisions
r = requests.get(f'http://localhost:5000/api/decisions/{session_id}')
decisions = r.json()
```

### JavaScript

```javascript
const API = 'http://localhost:5000/api';

// Upload file
async function uploadFile(file) {
    const formData = new FormData();
    formData.append('file', file);
    
    const response = await fetch(`${API}/upload`, {
        method: 'POST',
        body: formData
    });
    return response.json();
}

// Run pipeline
async function runPipeline(sessionId, targetColumn) {
    const response = await fetch(`${API}/pipeline/run`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            session_id: sessionId,
            target_column: targetColumn
        })
    });
    return response.json();
}

// Get decisions
async function getDecisions(sessionId) {
    const response = await fetch(`${API}/decisions/${sessionId}`);
    return response.json();
}
```

---

## Rate Limiting

Currently disabled. Enable in production:

```python
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

limiter = Limiter(app, key_func=get_remote_address)

@app.route('/api/upload', methods=['POST'])
@limiter.limit("5 per minute")
def upload_file():
    ...
```

---

## Pagination

Not yet implemented. For large datasets, use:

```
GET /api/data/<session_id>?page=1&limit=100
```

---

## Best Practices

1. **Store session_id** for subsequent requests
2. **Check status** before displaying results
3. **Handle errors** gracefully in frontend
4. **Clean up sessions** with DELETE when done
5. **Use JSON format** for data interchange

---

## Changelog

### v1.0.0 (Initial Release)
- File upload
- Pipeline execution
- Decision logging
- Error analysis
- Session management

---

**For support, see SETUP.md troubleshooting section**
