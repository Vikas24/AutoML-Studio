# 🚀 ML Pipeline Flask Backend - Setup Guide

## Quick Start (5 Minutes)

### Step 1: Install Dependencies

```bash
# Install Python packages
pip install flask flask-cors pandas scikit-learn imbalanced-learn numpy

# Or use requirements file (coming next)
pip install -r requirements.txt
```

### Step 2: Start Flask Backend

```bash
cd backend
python app.py
```

You should see:
```
 * Running on http://0.0.0.0:5000
 * Debug mode: on
```

### Step 3: Open Frontend

Open in your browser:
```
file://frontend/index.html
```

Or use a local web server:
```bash
cd frontend
python -m http.server 8000
```

Then open: `http://localhost:8000`

---

## Project Structure

```
ml_pipeline_flask/
│
├── backend/
│   ├── app.py                  # Flask API (main backend)
│   └── requirements.txt         # Python dependencies
│
├── frontend/
│   ├── index.html              # Web interface (single file)
│   └── README.md               # Frontend docs
│
└── docs/
    ├── API.md                  # REST API documentation
    └── DEPLOYMENT.md           # Production deployment guide
```

---

## 📡 REST API Endpoints

### Health Check
```
GET /api/health
```

Response:
```json
{
    "status": "healthy",
    "message": "ML Pipeline API is running"
}
```

### Upload File
```
POST /api/upload
Content-Type: multipart/form-data

Body:
  file: <CSV file>
```

Response:
```json
{
    "session_id": "abc123",
    "filename": "data.csv",
    "shape": [1000, 15],
    "columns": ["feature_1", "feature_2", ...],
    "preview": [...]
}
```

### Run Pipeline
```
POST /api/pipeline/run
Content-Type: application/json

Body:
{
    "session_id": "abc123",
    "target_column": "target"  // or null for unsupervised
}
```

Response:
```json
{
    "session_id": "abc123",
    "status": "success",
    "problem_type": "classification",
    "model": "RandomForestClassifier",
    "metrics": {...},
    "decisions": {...}
}
```

### Get Decisions
```
GET /api/decisions/<session_id>
```

Response:
```json
{
    "timestamp": "2024-02-03T10:30:00",
    "decisions": {
        "problem_type": {...},
        "model_selection": {...},
        ...
    }
}
```

---

## 🔧 Configuration

### Environment Variables

```bash
# Flask
FLASK_ENV=development
FLASK_DEBUG=true
FLASK_PORT=5000

# CORS
FLASK_CORS_ORIGINS=*

# Upload
MAX_UPLOAD_SIZE=104857600  # 100MB
```

### Flask Config (in app.py)

```python
app.config['UPLOAD_FOLDER'] = tempfile.gettempdir()
app.config['MAX_CONTENT_LENGTH'] = 100 * 1024 * 1024  # 100MB
```

---

## 🐍 Development

### Running with Debug

```bash
python app.py
```

Flask will auto-reload on file changes.

### Testing the API

Using curl:
```bash
# Check health
curl http://localhost:5000/api/health

# Upload file
curl -F "file=@data.csv" http://localhost:5000/api/upload

# Run pipeline
curl -X POST http://localhost:5000/api/pipeline/run \
  -H "Content-Type: application/json" \
  -d '{"session_id": "abc123", "target_column": "target"}'
```

Using Python:
```python
import requests

# Check health
r = requests.get('http://localhost:5000/api/health')
print(r.json())

# Upload file
with open('data.csv', 'rb') as f:
    files = {'file': f}
    r = requests.post('http://localhost:5000/api/upload', files=files)
    print(r.json())
```

---

## 🌐 Frontend Features

### Upload Tab
- Drag & drop CSV upload
- Data preview table
- Column information
- Target column selection

### Analysis Tab
- Data statistics
- Missing values
- Duplicates
- Data types

### Results Tab
- Model metrics (accuracy, F1, ROC-AUC)
- Decision flow visualization
- Error analysis
- Feature importance

### Report Tab
- Full decision log
- JSON export
- Text report export
- Audit trail

---

## 📊 Architecture

```
┌─────────────────────────────────────────────┐
│           Frontend (HTML/CSS/JS)            │
│        • Single-page application            │
│        • Modern, responsive UI              │
│        • Real-time updates                  │
└──────────────┬──────────────────────────────┘
               │ HTTP/AJAX
               ▼
┌─────────────────────────────────────────────┐
│      Flask Backend (Python API)             │
│    • REST endpoints                         │
│    • Session management                     │
│    • File handling                          │
│    • Pipeline execution                     │
└──────────────┬──────────────────────────────┘
               │
               ▼
┌─────────────────────────────────────────────┐
│     ML Pipeline (src/pipeline/)             │
│    • Data validation                        │
│    • Preprocessing                          │
│    • Model training                         │
│    • Error analysis                         │
└──────────────┬──────────────────────────────┘
               │
               ▼
┌─────────────────────────────────────────────┐
│   Decision Logger (src/logging/)            │
│    • Logs all decisions                     │
│    • Provides reasoning                     │
│    • Exports JSON/text                      │
└─────────────────────────────────────────────┘
```

---

## 🚀 Production Deployment

### Using Gunicorn

```bash
pip install gunicorn

# Run with Gunicorn
gunicorn --bind 0.0.0.0:5000 --workers 4 app:app
```

### Using Docker

```dockerfile
FROM python:3.9

WORKDIR /app

COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .

CMD ["gunicorn", "--bind", "0.0.0.0:5000", "app:app"]
```

Build and run:
```bash
docker build -t ml-pipeline-api .
docker run -p 5000:5000 ml-pipeline-api
```

### Using Nginx

```nginx
server {
    listen 80;
    server_name your-domain.com;

    location /api {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }

    location / {
        root /var/www/ml-pipeline;
        try_files $uri $uri/ /index.html;
    }
}
```

---

## 🔒 Security

### CORS Configuration

Currently allows all origins. For production:

```python
CORS(app, resources={
    r"/api/*": {
        "origins": ["https://yourdomain.com"],
        "methods": ["GET", "POST"],
        "allow_headers": ["Content-Type"]
    }
})
```

### File Upload Security

```python
ALLOWED_EXTENSIONS = {'csv'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS
```

### Rate Limiting

Install:
```bash
pip install flask-limiter
```

Add to app:
```python
from flask_limiter import Limiter

limiter = Limiter(app, key_func=lambda: request.remote_addr)

@app.route('/api/upload', methods=['POST'])
@limiter.limit("5 per minute")
def upload_file():
    ...
```

---

## 🐛 Troubleshooting

### Port Already in Use
```bash
# Find process using port 5000
lsof -i :5000

# Kill process
kill -9 <PID>

# Or use different port
python app.py --port 8000
```

### CORS Issues
```
Access to XMLHttpRequest blocked by CORS
```

Solution: Make sure Flask CORS is properly configured:
```python
from flask_cors import CORS
CORS(app)
```

### File Upload Issues
```
413 Request Entity Too Large
```

Solution: Increase max content length in app config:
```python
app.config['MAX_CONTENT_LENGTH'] = 500 * 1024 * 1024  # 500MB
```

### Module Not Found
```
ModuleNotFoundError: No module named 'flask'
```

Solution:
```bash
pip install flask flask-cors pandas scikit-learn
```

---

## 📚 API Response Format

### Success Response (200)
```json
{
    "status": "success",
    "data": {...},
    "message": "Operation completed"
}
```

### Error Response (400/500)
```json
{
    "error": "Descriptive error message",
    "code": "ERROR_CODE",
    "details": {...}
}
```

---

## 🔄 Session Management

Sessions are stored in memory. For production, use Redis:

```python
import redis
from flask_session import Session

app.config['SESSION_TYPE'] = 'redis'
app.config['SESSION_REDIS'] = redis.from_url('redis://localhost:6379')

Session(app)
```

---

## 📈 Performance

### Async Processing

For long-running pipelines, use Celery:

```bash
pip install celery redis
```

```python
from celery import Celery

celery = Celery(app.name, broker='redis://localhost:6379')

@celery.task
def run_pipeline_task(session_id, target_column):
    pipeline = MLPipeline()
    # ... run pipeline ...
    return results
```

---

## 🎯 Next Steps

1. **Start Backend**:  `python backend/app.py`
2. **Open Frontend**: `file://frontend/index.html`
3. **Upload CSV**: Drag & drop your data
4. **Run Pipeline**: Click "Run Pipeline"
5. **View Results**: See metrics & decisions

---

## 📞 Support

All endpoints documented in `/docs/API.md`

Questions? Check the troubleshooting section above.

---

**Ready to deploy? See DEPLOYMENT.md for production setup.**
