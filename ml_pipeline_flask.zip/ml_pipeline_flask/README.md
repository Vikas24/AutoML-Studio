# 🚀 ML Pipeline Flask Backend

**Production-ready Flask REST API for the ML Pipeline with beautiful modern frontend.**

Convert your ML Pipeline into a full-stack web application with Flask backend and HTML/CSS/JS frontend.

---

## ⚡ Quick Start (3 Minutes)

### 1. Install Dependencies
```bash
pip install -r backend/requirements.txt
```

### 2. Start Flask Server
```bash
python backend/app.py
```

You should see:
```
 * Running on http://0.0.0.0:5000
 * Debug mode: on
```

### 3. Open Frontend
```bash
# Option A: Open directly (simplest)
open frontend/index.html

# Option B: Use local web server
cd frontend
python -m http.server 8000
# Then visit: http://localhost:8000
```

### 4. Try It Out
1. Upload a CSV file (drag & drop)
2. Select target column (or leave empty for unsupervised)
3. Click "🚀 Run Pipeline"
4. View results and download decision report

---

## 📦 What You Get

### Backend (Flask)
- ✅ REST API with 14 endpoints
- ✅ Session management
- ✅ File upload handling
- ✅ Pipeline orchestration
- ✅ Error handling
- ✅ CORS enabled
- ✅ Production-ready

### Frontend (HTML/CSS/JS)
- ✅ Modern responsive design
- ✅ Beautiful dashboard
- ✅ Real-time feedback
- ✅ Drag & drop upload
- ✅ Results visualization
- ✅ Report generation
- ✅ Mobile-friendly
- ✅ Single HTML file (no build needed)

---

## 🏗️ Project Structure

```
ml_pipeline_flask/
│
├── backend/
│   ├── app.py                  # Flask API (main backend)
│   ├── requirements.txt        # Python dependencies
│   └── README.md              # Backend docs
│
├── frontend/
│   ├── index.html             # Complete frontend (single file!)
│   └── README.md              # Frontend docs
│
├── docs/
│   ├── API.md                 # REST API documentation
│   └── DEPLOYMENT.md          # Production deployment guide
│
├── SETUP.md                   # Installation & configuration guide
└── README.md                  # This file
```

---

## 📡 REST API Overview

14 REST endpoints for complete ML pipeline control:

### File Management
- `POST /api/upload` - Upload CSV file
- `GET /api/analysis/<session_id>/stats` - Get data stats
- `GET /api/analysis/<session_id>/columns` - Get column info

### Pipeline Execution
- `POST /api/pipeline/run` - Execute ML pipeline
- `GET /api/pipeline/status/<session_id>` - Get pipeline status

### Decision Logs
- `GET /api/decisions/<session_id>` - Get full decision log
- `GET /api/decisions/<session_id>/text` - Get text report
- `GET /api/decisions/<session_id>/stage/<stage>` - Get specific stage

### Export
- `GET /api/export/<session_id>/json` - Download decisions as JSON
- `GET /api/export/<session_id>/text` - Download report as text

### Session Management
- `GET /api/sessions` - List active sessions
- `DELETE /api/sessions/<session_id>` - Delete session

### Health
- `GET /api/health` - API health check
- `GET /api/version` - API version info

**Complete documentation in `/docs/API.md`**

---

## 🎨 Frontend Features

### 📤 Upload Tab
- Drag & drop CSV upload
- Data preview table
- Column information
- Missing values display
- Target column selection

### 🔍 Analysis Tab
- Data statistics
- Data types
- Missing value counts
- Duplicates
- Numeric summary

### 📊 Results Tab
- Model metrics (accuracy, F1, ROC-AUC, etc.)
- Decision flow visualization
- Error analysis insights
- Feature importance
- Model comparison

### 📋 Report Tab
- Full decision log (formatted)
- JSON export
- Text report export
- Copy to clipboard
- Download options

---

## 🔄 Data Flow

```
User ↓
 ├─ Opens frontend/index.html
 ├─ Uploads CSV file
 └─ Selects target column (optional)
 
 ↓
 
Frontend (HTML/CSS/JS) ↓
 ├─ Sends POST /api/upload
 ├─ Shows data preview
 ├─ Sends POST /api/pipeline/run
 └─ Displays results in real-time
 
 ↓
 
Backend (Flask) ↓
 ├─ Receives file
 ├─ Stores session
 ├─ Validates CSV
 └─ Returns preview
 
 ├─ Receives pipeline request
 ├─ Executes ML pipeline
 ├─ Logs all decisions
 └─ Returns results + decisions
 
 ↓
 
ML Pipeline ↓
 ├─ Loads & validates data
 ├─ Auto-detects problem type
 ├─ Preprocesses data
 ├─ Trains models
 ├─ Evaluates results
 └─ Analyzes errors
 
 ↓
 
Decision Logger ↓
 ├─ Logs all decisions
 ├─ Provides reasoning
 ├─ Formats output
 └─ Returns to frontend
```

---

## 📊 Example Usage

### Upload & Run

1. **Start backend**: `python backend/app.py`
2. **Open frontend**: Open `frontend/index.html` in browser
3. **Upload CSV**: Drag data.csv to upload area
4. **Select target**: Choose column to predict (or leave empty)
5. **Run pipeline**: Click "🚀 Run Pipeline"
6. **View results**: See metrics and decision log
7. **Download**: Export JSON or text report

### API Usage (Python)

```python
import requests

API = 'http://localhost:5000/api'

# 1. Upload file
with open('data.csv', 'rb') as f:
    files = {'file': f}
    r = requests.post(f'{API}/upload', files=files)
    session_id = r.json()['session_id']

# 2. Run pipeline
data = {'session_id': session_id, 'target_column': 'target'}
r = requests.post(f'{API}/pipeline/run', json=data)
results = r.json()

# 3. Get decisions
r = requests.get(f'{API}/decisions/{session_id}')
decisions = r.json()

print(f"Model: {results['model']}")
print(f"Accuracy: {results['metrics']['accuracy']}")
print(f"Decisions: {decisions['decisions']}")
```

### API Usage (JavaScript)

```javascript
const API = 'http://localhost:5000/api';

// Upload file
const formData = new FormData();
formData.append('file', fileInput.files[0]);
const uploadRes = await fetch(`${API}/upload`, {
    method: 'POST',
    body: formData
});
const { session_id } = await uploadRes.json();

// Run pipeline
const runRes = await fetch(`${API}/pipeline/run`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
        session_id,
        target_column: 'target'
    })
});
const results = await runRes.json();

// Get decisions
const decRes = await fetch(`${API}/decisions/${session_id}`);
const decisions = await decRes.json();
```

### API Usage (cURL)

```bash
# Upload
curl -F "file=@data.csv" http://localhost:5000/api/upload

# Run pipeline
curl -X POST http://localhost:5000/api/pipeline/run \
  -H "Content-Type: application/json" \
  -d '{"session_id": "abc123", "target_column": "target"}'

# Get decisions
curl http://localhost:5000/api/decisions/abc123
```

---

## 🚀 Deployment

### Local Development
```bash
python backend/app.py
# Open: file://frontend/index.html or http://localhost:8000
```

### Production with Gunicorn
```bash
pip install gunicorn
gunicorn --bind 0.0.0.0:5000 --workers 4 backend.app:app
```

### Production with Docker
```bash
docker build -t ml-pipeline-api .
docker run -p 5000:5000 ml-pipeline-api
```

### Production with Nginx
See `/docs/DEPLOYMENT.md` for complete Nginx configuration.

---

## 🔒 Security

### Current (Development)
- CORS: Allows all origins
- File upload: CSV only
- Max file size: 100MB
- No authentication

### Production (Recommended)
Add to `backend/app.py`:

```python
# 1. Restrict CORS
CORS(app, origins=['https://yourdomain.com'])

# 2. Add authentication
from flask_httpauth import HTTPBasicAuth
auth = HTTPBasicAuth()

@auth.verify_password
def verify_password(username, password):
    return username == 'admin' and password == 'secret'

@app.route('/api/pipeline/run', methods=['POST'])
@auth.login_required
def run_pipeline():
    ...

# 3. Add rate limiting
from flask_limiter import Limiter
limiter = Limiter(app, key_func=lambda: request.remote_addr)

@app.route('/api/upload', methods=['POST'])
@limiter.limit("10 per hour")
def upload():
    ...

# 4. Add HTTPS
# Use nginx reverse proxy with SSL
```

---

## 🛠️ Configuration

### Backend Configuration

**File**: `backend/app.py`

```python
# Port
FLASK_PORT = 5000

# Upload settings
UPLOAD_FOLDER = tempfile.gettempdir()
MAX_CONTENT_LENGTH = 100 * 1024 * 1024  # 100MB

# Debug
DEBUG = True  # Set to False in production
```

### Frontend Configuration

**File**: `frontend/index.html`

```javascript
// API base URL
const API_BASE = 'http://localhost:5000/api';

// Can be changed to:
const API_BASE = 'https://your-api.com/api';
```

---

## 📚 Documentation

- **SETUP.md** - Installation & configuration
- **docs/API.md** - Complete REST API reference
- **docs/DEPLOYMENT.md** - Production deployment
- **backend/README.md** - Backend documentation
- **frontend/README.md** - Frontend documentation

---

## 🐛 Troubleshooting

### Port Already in Use
```bash
# Find process
lsof -i :5000

# Kill it
kill -9 <PID>
```

### CORS Errors
Ensure Flask CORS is enabled:
```python
from flask_cors import CORS
CORS(app)  # in app.py
```

### File Upload Issues
Check max file size in `app.py`:
```python
app.config['MAX_CONTENT_LENGTH'] = 500 * 1024 * 1024  # 500MB
```

### Module Not Found
```bash
pip install -r backend/requirements.txt
```

---

## ✨ Features

- ✅ **Automated ML Pipeline** - Auto-detects problem type
- ✅ **Multiple Models** - Trains 6+ models automatically
- ✅ **Decision Logging** - Logs every decision with reasoning
- ✅ **Error Analysis** - False positives/negatives breakdown
- ✅ **Beautiful UI** - Modern, responsive dashboard
- ✅ **REST API** - 14 endpoints for full control
- ✅ **Session Management** - Multiple concurrent sessions
- ✅ **Export** - JSON & text reports
- ✅ **No Build Required** - Single HTML file frontend
- ✅ **Production Ready** - Security, error handling, logging

---

## 📊 Technology Stack

### Backend
- **Flask** - Web framework
- **Flask-CORS** - Cross-origin requests
- **Pandas** - Data processing
- **Scikit-learn** - ML models
- **NumPy** - Numerical computing

### Frontend
- **HTML5** - Markup
- **CSS3** - Styling (no framework needed!)
- **JavaScript** - Interactivity
- **Fetch API** - HTTP requests

### No Database Needed
- Sessions stored in memory
- Upload files in temp directory
- Perfect for standalone applications

---

## 🎯 Use Cases

### Data Science Teams
- Rapid prototyping
- Model comparison
- Decision explanation
- Team collaboration

### Business Analysts
- No coding required
- Upload & run
- Visual results
- Report generation

### Developers
- REST API for integration
- Python SDK ready
- Single-page app
- Easy to extend

---

## 🚀 Getting Started Checklist

- [ ] Install dependencies: `pip install -r backend/requirements.txt`
- [ ] Start backend: `python backend/app.py`
- [ ] Open frontend: `frontend/index.html`
- [ ] Upload sample CSV
- [ ] Run pipeline
- [ ] View results
- [ ] Download report

---

## 📈 Next Steps

1. **Development**
   - Customize frontend (add charts, animations)
   - Add authentication
   - Set up database for sessions
   - Deploy to cloud

2. **Production**
   - Use Gunicorn + Nginx
   - Enable HTTPS
   - Add rate limiting
   - Set up monitoring
   - Configure backups

3. **Enhancements**
   - Add deep learning models
   - Implement hyperparameter tuning
   - Add SHAP explanations
   - Create model marketplace

---

## 📞 Support

**Problems?**

1. Check **SETUP.md** troubleshooting section
2. Review **docs/API.md** for endpoint details
3. Check browser console for errors
4. Check Flask logs for backend issues

---

## 📜 License

This project is provided as-is for educational and commercial use.

---

## 🎉 You're Ready!

```bash
# 1. Install
pip install -r backend/requirements.txt

# 2. Run
python backend/app.py

# 3. Open
open frontend/index.html

# 4. Upload & run!
```

**Questions?** See SETUP.md

**Need API details?** See docs/API.md

**Want to deploy?** See docs/DEPLOYMENT.md

---

**Build something amazing! 🚀**
