"""
Flask Backend API for ML Pipeline
Provides REST endpoints for all ML operations
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
import os
import json
import tempfile
from werkzeug.utils import secure_filename
import sys
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent / 'ml_pipeline'))

from src.pipeline.run_pipeline import MLPipeline
from src.logging.decision_logger import DecisionLogger

# ============================================================================
# FLASK APP SETUP
# ============================================================================

app = Flask(__name__)
CORS(app)

# Configuration
UPLOAD_FOLDER = tempfile.gettempdir()
ALLOWED_EXTENSIONS = {'csv'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 100 * 1024 * 1024  # 100MB max

# Store pipelines in memory (use Redis for production)
pipelines = {}

# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def generate_session_id():
    import uuid
    return str(uuid.uuid4())[:8]

# ============================================================================
# HEALTH CHECK ENDPOINTS
# ============================================================================

@app.route('/api/health', methods=['GET'])
def health_check():
    """Check if API is running"""
    return jsonify({
        'status': 'healthy',
        'message': 'ML Pipeline API is running'
    }), 200

@app.route('/api/version', methods=['GET'])
def version():
    """Get API version"""
    return jsonify({
        'version': '1.0.0',
        'name': 'ML Pipeline API',
        'description': 'Automated ML pipeline with decision logging'
    }), 200

# ============================================================================
# FILE UPLOAD ENDPOINT
# ============================================================================

@app.route('/api/upload', methods=['POST'])
def upload_file():
    """Upload CSV file and return preview"""
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'No file provided'}), 400
        
        file = request.files['file']
        
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        if not allowed_file(file.filename):
            return jsonify({'error': 'Only CSV files allowed'}), 400
        
        # Save file
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        
        # Generate session ID
        session_id = generate_session_id()
        
        # Preview data
        import pandas as pd
        df = pd.read_csv(filepath)
        
        preview = {
            'session_id': session_id,
            'filename': filename,
            'filepath': filepath,
            'shape': df.shape,
            'columns': df.columns.tolist(),
            'dtypes': df.dtypes.astype(str).to_dict(),
            'preview': df.head(10).to_dict(orient='records'),
            'missing_values': df.isnull().sum().to_dict(),
            'sample_values': {col: df[col].unique()[:5].tolist() for col in df.columns}
        }
        
        # Store session
        pipelines[session_id] = {
            'filepath': filepath,
            'pipeline': None,
            'decisions': None
        }
        
        return jsonify(preview), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ============================================================================
# PIPELINE EXECUTION ENDPOINTS
# ============================================================================

@app.route('/api/pipeline/run', methods=['POST'])
def run_pipeline():
    """Run complete ML pipeline"""
    try:
        data = request.get_json()
        session_id = data.get('session_id')
        target_column = data.get('target_column')
        
        if not session_id or session_id not in pipelines:
            return jsonify({'error': 'Invalid session'}), 400
        
        filepath = pipelines[session_id]['filepath']
        
        # Run pipeline
        pipeline = MLPipeline()
        pipeline.load_data(filepath)
        pipeline.validate_data()
        pipeline.clean_data()
        pipeline.engineer_features()
        pipeline.determine_problem_type(target_column if target_column else None)
        pipeline.preprocess(scaling_method='standard')
        pipeline.select_features()
        
        if pipeline.is_supervised:
            pipeline.split_data(test_size=0.2, stratify=True)
            pipeline.handle_imbalance()
            pipeline.train_model()
            metrics = pipeline.evaluate()
            pipeline.error_analysis()
        else:
            clusters = pipeline.unsupervised_pipeline()
        
        # Store pipeline
        pipelines[session_id]['pipeline'] = pipeline
        pipelines[session_id]['decisions'] = pipeline.get_decisions()
        
        # Return results
        decisions = pipeline.get_decisions()
        
        result = {
            'session_id': session_id,
            'status': 'success',
            'problem_type': decisions['decisions'].get('problem_type', {}).get('type'),
            'decisions': decisions['decisions'],
            'model': decisions['decisions'].get('model_selection', {}).get('selected_model') if pipeline.is_supervised else 'Unsupervised',
            'metrics': decisions['decisions'].get('evaluation', {}).get('metrics') if pipeline.is_supervised else None
        }
        
        return jsonify(result), 200
    
    except Exception as e:
        return jsonify({'error': str(e), 'traceback': str(e.__traceback__)}), 500

@app.route('/api/pipeline/status/<session_id>', methods=['GET'])
def pipeline_status(session_id):
    """Get pipeline status"""
    try:
        if session_id not in pipelines:
            return jsonify({'error': 'Invalid session'}), 400
        
        pipeline = pipelines[session_id]['pipeline']
        
        if pipeline is None:
            return jsonify({
                'session_id': session_id,
                'status': 'pending',
                'message': 'Pipeline not yet executed'
            }), 200
        
        decisions = pipelines[session_id]['decisions']
        
        return jsonify({
            'session_id': session_id,
            'status': 'completed',
            'problem_type': decisions['decisions'].get('problem_type', {}).get('type'),
            'model': decisions['decisions'].get('model_selection', {}).get('selected_model') if pipeline.is_supervised else 'Unsupervised'
        }), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ============================================================================
# DECISION LOG ENDPOINTS
# ============================================================================

@app.route('/api/decisions/<session_id>', methods=['GET'])
def get_decisions(session_id):
    """Get full decision log"""
    try:
        if session_id not in pipelines or pipelines[session_id]['decisions'] is None:
            return jsonify({'error': 'No decisions found for this session'}), 404
        
        decisions = pipelines[session_id]['decisions']
        return jsonify(decisions), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/decisions/<session_id>/text', methods=['GET'])
def get_decisions_text(session_id):
    """Get decision log as text report"""
    try:
        if session_id not in pipelines or pipelines[session_id]['pipeline'] is None:
            return jsonify({'error': 'No decisions found for this session'}), 404
        
        pipeline = pipelines[session_id]['pipeline']
        report = pipeline.generate_report()
        
        return jsonify({
            'session_id': session_id,
            'report': report
        }), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/decisions/<session_id>/stage/<stage_name>', methods=['GET'])
def get_stage_decision(session_id, stage_name):
    """Get decision for specific pipeline stage"""
    try:
        if session_id not in pipelines or pipelines[session_id]['decisions'] is None:
            return jsonify({'error': 'No decisions found'}), 404
        
        decisions = pipelines[session_id]['decisions']['decisions']
        
        if stage_name not in decisions:
            return jsonify({'error': f'Stage {stage_name} not found'}), 404
        
        return jsonify({
            'stage': stage_name,
            'decision': decisions[stage_name]
        }), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ============================================================================
# EXPORT ENDPOINTS
# ============================================================================

@app.route('/api/export/<session_id>/json', methods=['GET'])
def export_json(session_id):
    """Export decisions as JSON"""
    try:
        if session_id not in pipelines or pipelines[session_id]['decisions'] is None:
            return jsonify({'error': 'No decisions to export'}), 404
        
        decisions = pipelines[session_id]['decisions']
        
        return jsonify({
            'filename': f'pipeline_decisions_{session_id}.json',
            'data': decisions
        }), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/export/<session_id>/text', methods=['GET'])
def export_text(session_id):
    """Export decision report as text"""
    try:
        if session_id not in pipelines or pipelines[session_id]['pipeline'] is None:
            return jsonify({'error': 'No report to export'}), 404
        
        pipeline = pipelines[session_id]['pipeline']
        report = pipeline.generate_report()
        
        return jsonify({
            'filename': f'pipeline_report_{session_id}.txt',
            'content': report
        }), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ============================================================================
# ANALYSIS ENDPOINTS
# ============================================================================

@app.route('/api/analysis/<session_id>/stats', methods=['GET'])
def get_stats(session_id):
    """Get data statistics"""
    try:
        if session_id not in pipelines:
            return jsonify({'error': 'Invalid session'}), 404
        
        import pandas as pd
        filepath = pipelines[session_id]['filepath']
        df = pd.read_csv(filepath)
        
        stats = {
            'shape': df.shape,
            'columns': df.columns.tolist(),
            'dtypes': df.dtypes.astype(str).to_dict(),
            'missing': df.isnull().sum().to_dict(),
            'duplicates': int(df.duplicated().sum()),
            'numeric_summary': df.describe().to_dict()
        }
        
        return jsonify(stats), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/analysis/<session_id>/columns', methods=['GET'])
def get_columns(session_id):
    """Get column information"""
    try:
        if session_id not in pipelines:
            return jsonify({'error': 'Invalid session'}), 404
        
        import pandas as pd
        filepath = pipelines[session_id]['filepath']
        df = pd.read_csv(filepath)
        
        columns_info = []
        for col in df.columns:
            columns_info.append({
                'name': col,
                'dtype': str(df[col].dtype),
                'missing': int(df[col].isnull().sum()),
                'unique': int(df[col].nunique()),
                'sample': df[col].dropna().head(3).tolist()
            })
        
        return jsonify({'columns': columns_info}), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ============================================================================
# SESSION MANAGEMENT
# ============================================================================

@app.route('/api/sessions', methods=['GET'])
def list_sessions():
    """List all active sessions"""
    sessions_list = []
    for sid, data in pipelines.items():
        sessions_list.append({
            'session_id': sid,
            'has_file': data['filepath'] is not None,
            'has_results': data['pipeline'] is not None
        })
    
    return jsonify({'sessions': sessions_list}), 200

@app.route('/api/sessions/<session_id>', methods=['DELETE'])
def delete_session(session_id):
    """Delete session and clean up"""
    try:
        if session_id in pipelines:
            filepath = pipelines[session_id].get('filepath')
            if filepath and os.path.exists(filepath):
                os.remove(filepath)
            del pipelines[session_id]
            return jsonify({'message': 'Session deleted'}), 200
        else:
            return jsonify({'error': 'Session not found'}), 404
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ============================================================================
# ERROR HANDLERS
# ============================================================================

@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Endpoint not found'}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'error': 'Internal server error'}), 500

# ============================================================================
# RUN SERVER
# ============================================================================

if __name__ == '__main__':
    # Create uploads directory
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    
    # Run Flask app
    app.run(
        host='0.0.0.0',
        port=5000,
        debug=True,
        threaded=True
    )
